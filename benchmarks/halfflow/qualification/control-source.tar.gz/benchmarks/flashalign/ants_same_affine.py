#!/usr/bin/env python3
"""ANTs nonlinear reference from an independently verified saved RAS affine.

No labels enter fitting. The input matrix maps moving RAS to fixed RAS;
ITK's image resampler requires its inverse in LPS coordinates.
"""
import argparse
import json
from pathlib import Path
import time

import ants
import nibabel as nib
import numpy as np
from real_image_court import sha, write_json, sample


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--affine',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--verify-only',action='store_true')
    args=parser.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=False)
    ants.config.set_ants_deterministic(True,seed_value=20261002)
    fixed,moving=[ants.image_read(str(args.data/(n+'.nii.gz'))) for n in ('fixed','moving')]
    ni={n:nib.load(args.data/(n+'.nii.gz')) for n in ('fixed','moving')}
    mask=ants.image_read(str(args.data/'fixed-mask.nii.gz'))
    forward=np.asarray(json.loads(args.affine.read_text())).reshape(4,4)
    flip=np.diag([-1.,-1.,1.,1.]);pull=flip@np.linalg.inv(forward)@flip
    transform=ants.create_ants_transform(transform_type='AffineTransform',precision='double',dimension=3,
        matrix=pull[:3,:3],translation=pull[:3,3],center=(0,0,0))
    path=out/'supplied-affine.mat';ants.write_transform(transform,str(path))
    persisted=ants.read_transform(str(path),precision='double')
    points=np.asarray([[0.,0.,0.],[17.5,-39.2,8.3],[-71.,52.4,91.8]])
    observed=np.asarray([persisted.apply_to_point(tuple(p)) for p in points])
    expected=nib.affines.apply_affine(pull,points)
    point_error=float(np.abs(observed-expected).max());assert point_error<2e-5
    warped=ants.apply_transforms(fixed,moving,transformlist=[str(path)],whichtoinvert=[False],interpolator='linear')
    ants.image_write(warped,str(out/'affine-warped.nii.gz'))
    world=nib.affines.apply_affine(ni['fixed'].affine,np.moveaxis(np.indices(ni['fixed'].shape),0,-1))
    coords=nib.affines.apply_affine(np.linalg.inv(forward),world)
    independent,valid=sample(ni['moving'].get_fdata(),ni['moving'].affine,coords)
    indices=nib.affines.apply_affine(np.linalg.inv(ni['moving'].affine),coords)
    interior=valid & np.all((indices>=1)&(indices<=np.asarray(ni['moving'].shape)-2),axis=-1)
    brain=nib.load(args.data/'fixed-mask.nii.gz').get_fdata()>0
    region=interior&brain;assert region.any()
    error=float(np.abs(independent-nib.load(out/'affine-warped.nii.gz').get_fdata())[region].max())
    write_json(out/'initialization-verification.json',dict(moving_to_fixed_ras_sha256=sha(args.affine),
        itk_pull_lps_matrix=pull.tolist(),persisted_point_max_abs_mm=point_error,
        independent_brain_warp_max_abs=error,evaluated_voxels=int(region.sum()),
        brain_fraction=float(region[brain].mean()),image_tolerance=1e-4,point_tolerance_mm=2e-5))
    assert error<1e-4, 'ANTs initialization differs from the supplied affine'
    if args.verify_only:
        print('Verified supplied affine:', point_error, 'mm point error;', error, 'image error')
        return
    settings=dict(type_of_transform='SyNOnly',syn_metric='CC',syn_sampling=2,reg_iterations=(40,20,0),
        grad_step=0.2,flow_sigma=3,total_sigma=0,mask_all_stages=True,verbose=True)
    write_json(out/'settings.json',dict(antspyx_version=ants.__version__,settings=settings,
        seed=20261002,seed_api='ants.config.set_ants_deterministic',
        initialization_sha256=sha(args.affine),fixed_sha256=sha(args.data/'fixed.nii.gz'),
        moving_sha256=sha(args.data/'moving.nii.gz')))
    started=time.monotonic()
    result=ants.registration(fixed,moving,initial_transform=str(path),mask=mask,outprefix=str(out/'ants-'),**settings)
    ants.image_write(result['warpedmovout'],str(out/'warped.nii.gz'))
    ants.image_write(result['warpedfixout'],str(out/'inverse-warped.nii.gz'))
    assert len(result['fwdtransforms'])==len(result['invtransforms'])==2
    # The collapse operation must retain the exact supplied affine, not optimize it.
    affine_path=next(p for p in result['fwdtransforms'] if p.endswith('.mat'))
    collapsed=ants.read_transform(affine_path,precision='double')
    collapse_error=float(np.abs(np.asarray([collapsed.apply_to_point(tuple(p)) for p in points])-expected).max())
    assert collapse_error<2e-5,'reference changed its initial affine'
    write_json(out/'result.json',dict(seconds=time.monotonic()-started,forward=result['fwdtransforms'],
        inverse=result['invtransforms'],collapsed_affine_point_error_mm=collapse_error))


if __name__=='__main__':main()
